scnShortcodeMeta = {
	attributes : [
			{
				label : "Title",
				id : "content",
				help : "The button title.",
			},
			{
				label : "Link",
				id : "link",
				help : "Optional link (e.g. http://google.com).",
			},
			{
				label : "Size",
				id : "size",
				help : "Values: &lt;empty&gt; for normal size, small, large, xl.",
				controlType : "select-control",
				selectValues : [ 'small', 'medium', 'large', 'xlarge' ],
				defaultValue : 'medium',
				defaultText : 'medium (Default)'
			},
			{
				label : "Background Color",
				id : "bgcolor",
				help : 'Or you can also choose your own color to use as the background for your button',
				controlType : "color-control"
			},
			{
				label : 'Variation',
				id : 'variation',
				help : 'Choose one of our predefined color skins to use with your list.',
				controlType : "select-control",
				selectValues : [ '', 'blue', 'chocolate', 'coral', 'cyan',
						'eggplant', 'electricblue', 'ferngreen', 'gold',
						'green', 'grey', 'khaki', 'ocean', 'orange',
						'palebrown', 'pink', 'purple', 'raspberry', 'red',
						'skyblue', 'slateblue' ],
				defaultValue : '',
				defaultText : 'Select'
			},
			{
				label : "Text Color",
				id : "textcolor",
				help : 'You can change the color of the text that appears on your button.',
				controlType : "color-control"
			},
			{
				label : "Align",
				id : 'align',
				help : 'Set the alignment for your button here.<br/>Your button will float along the center, left or right hand sides depending on your choice.',
				controlType : "select-control",
				selectValues : [ 'left', 'center', 'right' ],
				defaultValue : 'center',
				defaultText : 'center (Default)'
			},
			{
				label : "Target",
				id : 'target',
				help : 'Setting the target to _blank will open your page in a new tab when the reader clicks on the button.',
				controlType : "select-control",
				selectValues : [ '_blank', '_new', '_parent', '_self', '_top' ],
				defaultValue : '_blank',
				defaultText : '_blank (Default)'
			} ],
	defaultContent : "Click me!",
	shortcode : "dt_sc_button"

};